<?php
// Include the header and initialize the database connection
include 'partials/header.php';

// Check if the 'ID' parameter is set and valid
if (isset($_GET['ID']) && is_numeric($_GET['ID'])) {
    $ID = filter_var($_GET['ID'], FILTER_SANITIZE_NUMBER_INT);

    // Query to fetch the post
    $query = "SELECT * FROM posts WHERE ID=$ID";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        // Fetch the post details
        $post = mysqli_fetch_assoc($result);
    } else {
        // Redirect to blog page if the post is not found
        header('Location: ' . ROOT_URL . 'blog.php');
        die();
    }
} else {
    // Redirect to blog page if 'ID' is missing or invalid
    header('Location: ' . ROOT_URL . 'blog.php');
    die();
}
?>

<section class="singlepost">
    <div class="singlepost_container">
        <!-- Post Content -->
        <h2><?= $post['title'] ?></h2>
        <div class="post_author">
            <?php 
                $author_id = $post['author_id'];
                $author_query = "SELECT * FROM users WHERE ID=$author_id";
                $author_result = mysqli_query($conn, $author_query);
                $author = mysqli_fetch_assoc($author_result);
            ?>
            <div class="post_author-avatar">
                <img src="./images/<?= $author['avatar'] ?>" alt="">
            </div>
            <div class="post_author-info">
                <h5>By: <?= "{$author['firstname']} {$author['lastname']}" ?></h5>
                <small><?= date("M d, Y - H:i", strtotime($post['date_time'])) ?></small>
            </div>
        </div>
        <div class="singlepost_thumbnail">
            <img src="./images/<?= $post['thumbnail'] ?>" alt="">
        </div>
        <p><?= $post['body'] ?></p>

        <!-- Like Section -->
        <div class="like_section">
            <?php
            // Fetch the current like count from the posts table
            $like_count = $post['likes'];
            ?>
            <div class="like_section">
    <button class="like-btn" data-post-id="<?= $post['ID'] ?>">Like</button>
    <span id="like-count-<?= $post['ID'] ?>"><?= $post['likes'] ?> Likes</span>
</div>
        </div>

        <!-- Comment Section -->
        <?php
    // Decode comments stored as JSON in the `comment` column
$comments = !empty($post['comment']) ? json_decode($post['comment'], true) : [];
?>

<div class="comment_section">
    <h3>Comments</h3>
    <ul>
        <?php 
        $comments = json_decode($post['comment'], true) ?: [];
        foreach ($comments as $comment): ?>
            <li>
                <strong><?= $comment['name'] ?>:</strong>
                <p><?= $comment['comment'] ?></p>
                <small><?= date("M d, Y - H:i", strtotime($comment['date_time'])) ?></small>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

        
        <!-- Add Comment Form -->
        <form id="comment-form" action="scripts/add_comment.php" method="POST">
    <input type="hidden" name="post_id" value="<?= $post['ID'] ?>"> <!-- post ID -->
    <textarea name="comment" rows="4" placeholder="Write a comment..." required></textarea>
    <button type="submit">Submit</button>
</form>
</section>

<!-- Link to your JavaScript file -->
<script src="js/like.js"></script>
<script src="js/comment.js"></script> <!-- Link to comment.js -->

<?php include 'partials/footer.php'; ?>
