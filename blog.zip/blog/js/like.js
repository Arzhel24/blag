document.querySelector('.like-btn').addEventListener('click', function () {
    const postId = this.getAttribute('data-post-id');
    const likeCountSpan = document.getElementById(`like-count-${postId}`);

    fetch('like_post.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `post_id=${postId}`,
    })
        .then((response) => response.text())
        .then((data) => {
            if (!isNaN(data)) {
                likeCountSpan.textContent = `${data} Likes`; // Update like count
            } else {
                console.error('Error updating likes:', data);
            }
        })
        .catch((error) => console.error('Error:', error));
});