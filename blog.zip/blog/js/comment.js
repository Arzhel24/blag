document.getElementById('comment-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('add_comment.php', {
        method: 'POST',
        body: formData,
    })
        .then((response) => response.text())
        .then((data) => {
            if (data.includes('Error')) {
                console.error(data);
            } else {
                location.reload(); // Reload page to show new comment
            }
        })
        .catch((error) => console.error('Error:', error));
});