<?php

    require '../partials/header.php';

    if(!isset($_SESSION['user_id']))
    {
        header('Location: ' .ROOT_URL. 'signin.php');
        die();
    }
?>
