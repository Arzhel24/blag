<?php
include 'partials/header.php'; // Ensure $conn is initialized

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_id = filter_var($_POST['post_id'], FILTER_SANITIZE_NUMBER_INT);

    if ($post_id) {
        // Increment the like count
        $query = "UPDATE posts SET likes = likes + 1 WHERE ID = $post_id";

        if (mysqli_query($conn, $query)) {
            // Return the updated like count
            $get_likes_query = "SELECT likes FROM posts WHERE ID = $post_id";
            $likes_result = mysqli_query($conn, $get_likes_query);
            $likes = mysqli_fetch_assoc($likes_result);
            echo $likes['likes'];
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Invalid Post ID.";
    }
}
?>