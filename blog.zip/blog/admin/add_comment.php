<?php
include 'partials/header.php'; // Ensure $conn is initialized

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_id = filter_var($_POST['post_id'], FILTER_SANITIZE_NUMBER_INT);
    $user_id = $_SESSION['user_id']; // Assumes user ID is stored in session
    $comment = filter_var($_POST['comment'], FILTER_SANITIZE_STRING);

    // Validate input
    if ($post_id && $user_id && $comment) {
        $query = "INSERT INTO comments (post_id, user_id, comment, date_time) 
                  VALUES ($post_id, $user_id, '$comment', NOW())";

        if (mysqli_query($conn, $query)) {
            header('Location: ' . ROOT_URL . "post.php?ID=$post_id");
            die();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Invalid input data.";
    }
}
?>